var divs = document.getElementsByClassName("tecla");
var display = document.getElementById("display").innerHTML;
var nuevodisplay;
var tipo;
var operando1="";
var operando2="";
var resultado=0;
var idTecla;
var operador="otro";
var lastOperador="otro";
var anchoActual;
var altoActual;
var altoInicio;
var anchoInicio;


for (var i=0; i< divs.length; i++) {
    divs[i].addEventListener("mousedown", mouseDown);

      function mouseDown(){

      anchoActual=this.width;
      altoActual=this.height;
      anchoInicio = this.width;
      altoInicio = this.height;
      this.style.width = Math.round(anchoActual*.90)+"px";
      this.style.height = Math.round(altoActual*.95)+"px";
    }

    divs[i].addEventListener("mouseup", mouseUp);

    function mouseUp(){
      this.style.width = anchoInicio+"px";
      this.style.height = altoInicio+"px";
    }


      divs[i].addEventListener("click",function Calculadora(){
      var idTecla = this.id;
      identificaTecla ();



      function identificaTecla(){
        if (!isNaN(idTecla)){
            tipo = "numero";
            if(document.getElementById("display").innerHTML=="0"){
               display="";
             }
             if (display.length<8){
             display = display+idTecla;
           } display;

               document.getElementById("display").innerHTML = display;
               operandos();


             } else {

            if(idTecla=="punto"){
                if (display=="0"){
                  display = "0."
                  document.getElementById("display").innerHTML = display;
                  lastOperador = operador;
                  operador="otro";

                } else {
                  if (!display.includes("."))
    						{
    						display = document.getElementById("display").innerHTML + '.';
    						}
    					    else
    						{
    						display = document.getElementById("display").innerHTML;
    						}
                  document.getElementById("display").innerHTML = display;
                  lastOperador = operador;
                  operador="otro";
                }
                } else {
                  if(idTecla=="sign"){
                    display= display+""
                    console.log("cambiasigno"+display)
                    if ( display.indexOf("-") == 0 || display=="Undefined" || display=="0")
                    { display = display.substring(1);
                      document.getElementById("display").innerHTML = "0";
                    } else
                    { display = "-" + display;
                    document.getElementById("display").innerHTML = display;
                    }

                } else {
                      if(idTecla=="on"){
                        document.getElementById("display").innerHTML="";
                        document.getElementById("display").innerHTML=0;
                        operador1 = 0;
                        operador2 = 0;
                        display="0"
                        resultado=0
                      } else {
                        if(idTecla=="igual"){
                          operando2=display;
                          operadores();
                          lastOperador="igual";
                        }
                      }
                    }
          if (resultado ==0) {
          operando1 = display;
          operadores();
          } else {
          resultado
          tipo = "operador";
          operador = "otro";

        }
        }
      }
    }

          function operadores(){
            if ((idTecla=="por") || (idTecla=="igual" && lastOperador=="por")){
              operador="por";
              multiplicacion();
            } else if ((idTecla=="menos") || (idTecla=="igual" && lastOperador=="resta")){
              operador="resta";
              resta();
            } else if ((idTecla=="dividido") || (idTecla=="igual" && lastOperador=="dividido")){
              operador="dividido";
              division();
            } else if ((idTecla=="mas") || (idTecla=="igual" && lastOperador=="mas")){
              operador ="mas";
              suma();
            } else if (operador=="raiz"){
              operador="raiz";
              raiz();
            }
          }

          function multiplicacion(){
            if (idTecla=="igual" && operando2!="" && operador=="por"){
              resultado = operando1 * operando2
              resultado=resultado.toString();

              if (resultado.length<8){
              document.getElementById("display").innerHTML = resultado;
              }
              resultado = resultado.substring(0,8);
              document.getElementById("display").innerHTML = resultado;

              display = resultado;
              operando1=resultado;
              operando2="";
              resultado="0";
              lastOperador="por";

              } else {
                console.log("operando1 por="+operando1)
                console.log("operando2 por="+operando2)
                document.getElementById("display").innerHTML=0;
                display=0;
                lastOperador="por";
              }
            }
          function resta(){
              if (idTecla=="igual" && operando2!="" && operador=="resta"){
                resultado = operando1 - operando2
                resultado=resultado.toString();
                if (resultado.length<8){
                document.getElementById("display").innerHTML = resultado;
                }
                resultado = resultado.substring(0,8);
                document.getElementById("display").innerHTML = resultado;
                display = resultado;
                operando1=resultado;
                operando2="";
                resultado ="0";
                lastOperador="resta";
                } else {
                  console.log("operando1 resta="+operando1)
                  console.log("operando2 resta="+operando2)
                  document.getElementById("display").innerHTML=0;
                  lastOperador="resta";
                  display=0;

            }
          }
          function division(){
              if (idTecla=="igual" && operando2!="" && operador=="dividido"){
                resultado = operando1 / operando2
                resultado=resultado.toString();
                if (resultado.length<8){
                document.getElementById("display").innerHTML = resultado;
                }
                resultado = resultado.substring(0,8);
                document.getElementById("display").innerHTML = resultado;
                display = resultado;
                operando1=resultado;
                operando2="";
                resultado ="0";
                lastOperador="dividido";
                } else {
                  console.log("operando1 div="+operando1)
                  console.log("operando2 div="+operando2)
                  document.getElementById("display").innerHTML=0;
                  lastOperador="dividido";
                  display=0;


            }
          }
          function suma(){
              if (idTecla=="igual" && operando2!="" && lastOperador=="mas"){
                resultado = eval(operando1) + eval(operando2)
                resultado=resultado.toString();
                if (resultado.length<8){
                document.getElementById("display").innerHTML = resultado;
                }
                resultado = resultado.substring(0,8);
                document.getElementById("display").innerHTML = resultado;
                display = resultado;
                operando1=resultado;
                operando2="";
                resultado ="0";
                lastOperador="mas";
                } else {
                  console.log("operando1 mas="+operando1)
                  console.log("operando2 mas="+operando2)
                  document.getElementById("display").innerHTML=0;
                  display=0;
                  lastOperador="mas";
                  display=0;


            }
          }
          function raiz(){
              if (idTecla=="igual" && operando2!="" && operador=="raiz"){
                resultado = Math.sqrt(operando1)
                document.getElementById("display").innerHTML = resultado;
                display = resultado;
                operando1=resultado;
                operando2="";
                resultado = "0";
                } else {
                  console.log("operando1 resta="+operando1)
                  console.log("operando2 resta="+operando2)
                  document.getElementById("display").innerHTML=0;

            }
          }

            function operandos(){
              console.log(operando1)
              console.log(operador)
              if (operando1=="" && operador!="otro"){
                operando1 = display;
                document.getElementById("display").innerHTML = operando1;
                //document.getElementById("display").innerHTML="";
              } else {
                if (operando2=="" && lastOperador!= "otro"){
                operando2= display;
                document.getElementById("display").innerHTML = operando2;
              }

              }
            }


    });
  }
